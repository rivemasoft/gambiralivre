define( function ( require ) {

	"use strict";

	return {
		app_slug : 'gambiralivre',
		wp_ws_url : 'https://www.gambiralivre.com.br/wp-appkit-api/gambiralivre',
		wp_url : 'https://www.gambiralivre.com.br',
		theme : 'q-android',
		version : '1.0',
		app_type : 'phonegap-build',
		app_title : 'GambiraLivre',
		app_platform : 'android',
		app_path: '',
		gmt_offset : -3,
		debug_mode : 'off',
		auth_key : 'g^)nj#+uV~FT[FuA`s5uZK9zQ>{/daZgc{j%zwSlE^yt6U:cR;G^K2yDb9*TfnE_',
		options : {"refresh_interval":0},
		theme_settings : [],
		addons : []
	};

});
